class Computer:
    def __init__(self, board, depth):
        self.board = board
        self.depth = depth
    def MinMaxAlgorithm(self):
        pass
    def MinMaxAlphaBetaPruning(self,depth, turn, alpha, beta):
        pass
